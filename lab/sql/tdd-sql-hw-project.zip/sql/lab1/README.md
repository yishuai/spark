# Lab 1
Name the file lab1.sql


## Getting started
see: https://www.ida.liu.se/~TDDD37/labs/mysqllabs/index.en.shtml


## The lab report
* See the example **lab1.sql** file for the report structure

* The questions should be answered in chronological order. 
r
* The file should be able to run using `SOURCE lab1.sql;` in MySQL without error.

* All created tables and views should be deleted in the beginning of the file.

* The written questions should be within SQL-comments. 
"/* like this */ "