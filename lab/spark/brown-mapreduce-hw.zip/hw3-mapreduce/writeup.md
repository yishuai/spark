# MapReduce Write Up

## Written questions

1. Your response to Question 1 here.

2. Your response to Question 2 here.

4. Your response to Question 5 here. You can also choose to *additionally* respond directly to the student's post on Piazza!

## README

If you have anything to note to the TAs about your submission, please put it in this section.